import React from "react";



const LoadingPage: React.FC = () => {
  return (
<div>
    ㅎㅇ
</div>
  );
};

export default LoadingPage;




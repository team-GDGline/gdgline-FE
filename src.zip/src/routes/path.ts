export const RouterPath = {
  root: "/",
  start: "/",
  main: "/main",
  book: "/book",
  loading: "/loading",
  analysis: "/analysis",
  notFound: "/notFound",
};
